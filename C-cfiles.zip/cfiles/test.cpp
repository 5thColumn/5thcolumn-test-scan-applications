#include "light.h"

Light::Light () : on(false) {
}

void Light::toggle() {
  on = (!on);
}

bool Light::isOn() const {
  return on;
}