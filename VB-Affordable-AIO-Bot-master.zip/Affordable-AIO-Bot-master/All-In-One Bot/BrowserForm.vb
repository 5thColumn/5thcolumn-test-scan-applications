﻿'@author Yu Lin
'https://github.com/yulin12345
'admin@yulin12345.site
'This form will display the browser.

Public Class BrowserForm

    Private Sub BrowserForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class